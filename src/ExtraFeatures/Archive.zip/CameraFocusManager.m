//
//  CameraFocusManager.m
//  iOSRTMP
//
//  Created by Mihai on 29/10/14.
//  Copyright (c) 2014 Agilio. All rights reserved.
//

#import "CameraFocusManager.h"
#import <QuartzCore/QuartzCore.h>

@implementation CameraFocusManager

static AVCaptureVideoPreviewLayer *previewOutput_ = nil;
static AVCaptureInput *videoInput_ = nil;
static UIView *preview_ = nil;
static UITapGestureRecognizer *tapRecognizer_ = nil;

+ (void)addTapToFocusFeatureForPreview:(UIView *)preview videoPreviewLayer:(AVCaptureVideoPreviewLayer *)previewOutput andVideoCpatureInput:(AVCaptureInput *)videoInput
{
    previewOutput_ = previewOutput;
    videoInput_ = videoInput;
    
    UITapGestureRecognizer *tapRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(focusAndExposeTap:)];
    tapRecognizer_ = tapRecognizer;
    
    [preview addGestureRecognizer: tapRecognizer];
}

#pragma mark - Tap To Focus

+ (void)focusAndExposeTap:(UIGestureRecognizer *)gestureRecognizer
{
    CGPoint devicePoint = [previewOutput_ captureDevicePointOfInterestForPoint:[gestureRecognizer locationInView:[gestureRecognizer view]]];
    
    CGPoint touchPoint = [gestureRecognizer locationInView: [gestureRecognizer view]];
    
    NSLog(@"point (%.2f, %.2f)", touchPoint.x, touchPoint.y);
    
    CameraFocusSquare *camFocus = [[CameraFocusSquare alloc]initWithFrame:CGRectMake(touchPoint.x-40, touchPoint.y-40, 80, 80)];
    [camFocus setBackgroundColor:[UIColor clearColor]];
    [previewOutput_ addSublayer:camFocus.layer];
    [camFocus setNeedsDisplay];
    
    [UIView animateWithDuration: 1.5
                     animations: ^{
                         camFocus.alpha = 0.0;
                         [camFocus.layer removeFromSuperlayer];
                         [camFocus release];
                     }];
    
    [self focusWithMode:AVCaptureFocusModeAutoFocus exposeWithMode:AVCaptureExposureModeAutoExpose atDevicePoint:devicePoint monitorSubjectAreaChange:YES];
}

+ (void)changeVideoInput:(AVCaptureInput *)videoInput
{
    videoInput_ = nil;
    videoInput_ = videoInput;
}

+ (void)focusWithMode:(AVCaptureFocusMode)focusMode exposeWithMode:(AVCaptureExposureMode)exposureMode atDevicePoint:(CGPoint)point monitorSubjectAreaChange:(BOOL)monitorSubjectAreaChange
{
    //dispatch_async([self sessionQueue], ^{
    AVCaptureDevice *device = [(AVCaptureDeviceInput*)videoInput_ device];
    NSError *error = nil;
    if ([device lockForConfiguration:&error])
    {
        if ([device isFocusPointOfInterestSupported] && [device isFocusModeSupported:focusMode])
        {
            [device setFocusPointOfInterest:point];
            [device setFocusMode:focusMode];
        }
        if ([device isExposurePointOfInterestSupported] && [device isExposureModeSupported:exposureMode])
        {
            [device setExposurePointOfInterest:point];
            [device setExposureMode:exposureMode];
        }
        [device setSubjectAreaChangeMonitoringEnabled:monitorSubjectAreaChange];
        [device unlockForConfiguration];
    }
    else
    {
        NSLog(@"%@", error);
    }
    //});
}

+ (void)removeTapToFocus
{
    [preview_ removeGestureRecognizer: tapRecognizer_];
    
    videoInput_ = nil;
    previewOutput_ = nil;
    preview_ = nil;
    tapRecognizer_ = nil;
}

@end

const float squareLength = 80.0f;
@implementation CameraFocusSquare

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        
        [self setBackgroundColor:[UIColor clearColor]];
        [self.layer setBorderWidth:2.0];
        [self.layer setCornerRadius:4.0];
        [self.layer setBorderColor:[UIColor whiteColor].CGColor];
        
        CABasicAnimation* selectionAnimation = [CABasicAnimation
                                                animationWithKeyPath:@"borderColor"];
        selectionAnimation.toValue = (id)[UIColor blueColor].CGColor;
        selectionAnimation.repeatCount = 2;
        [self.layer addAnimation:selectionAnimation
                          forKey:@"selectionAnimation"];
        
    }
    return self;
}
@end
