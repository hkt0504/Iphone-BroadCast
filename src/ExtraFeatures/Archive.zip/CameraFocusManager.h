//
//  CameraFocusManager.h
//  iOSRTMP
//
//  Created by Mihai on 29/10/14.
//  Copyright (c) 2014 Agilio. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>

@interface CameraFocusManager : NSObject

+ (void)addTapToFocusFeatureForPreview:(UIView *)preview videoPreviewLayer:(AVCaptureVideoPreviewLayer*)previewOutput andVideoCpatureInput:(AVCaptureInput*)videoInput;
+ (void)changeVideoInput:(AVCaptureInput *)videoInput;
+ (void)removeTapToFocus;

@end

@interface CameraFocusSquare : UIView

@end
